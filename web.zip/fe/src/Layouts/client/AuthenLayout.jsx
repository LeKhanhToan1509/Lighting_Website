const AuthenLayout = ({ children }) => {
    return (
        <div>
            {children}
        </div>
    );
}